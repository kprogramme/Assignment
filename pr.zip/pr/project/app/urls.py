from django.urls import path
from . import views
urlpatterns = [
    path('', views.front, name="front"),
    path('account', views.account, name="account"),
    path('login', views.login, name="login"),
    path('task', views.task, name="task"),
    path('assignment', views.assignmentc, name="assignment"),


]