from django.contrib import admin
from .models import Account_details,employ_details,task_details
# Register your models here.
admin.site.register(Account_details)
admin.site.register(employ_details)
admin.site.register(task_details)